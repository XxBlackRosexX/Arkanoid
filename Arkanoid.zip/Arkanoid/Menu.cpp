#include "Menu.h"

Menu::Menu(float width, float height)
{
	if (!font.loadFromFile("arial.ttf"))
	{
		//handle error
	}

	menu[0].setFont(font);
	menu[0].setFillColor(Color::Black);
	menu[0].setString("Play");
	menu[0].setPosition(Vector2f(width / 2, height / (MAX_NUMBER_OF_ITEMS + 1)));

	menu[1].setFont(font);
	menu[1].setFillColor(Color::Black);
	menu[1].setString("Exit");
	menu[1].setPosition(Vector2f(width / 2, height / (MAX_NUMBER_OF_ITEMS + 1) * 2));

}

void Menu::draw(RenderWindow& window)
{
	for (int i = 0; i < MAX_NUMBER_OF_ITEMS; i++)
	{
		window.draw(menu[i]);
	}

}

int Menu::update(RenderWindow& window)
{
	for (size_t i = 0; i < MAX_NUMBER_OF_ITEMS; i++)
	{
		if (on_mouse_over(menu[i], window))
		{
			menu[i].setFillColor(Color::Cyan);
			Mouse mouse;
			if (mouse.isButtonPressed(Mouse::Left))
			{
				return i;
			}
		}
		else
		{
			menu[i].setFillColor(Color::Black);
		}
	}
	return -1;
}

bool Menu::on_mouse_over(Text text_to_check,RenderWindow& window)
{
	Mouse mouse;
	float left = text_to_check.getGlobalBounds().left;
	float right = text_to_check.getGlobalBounds().left + text_to_check.getGlobalBounds().width;
	float top = text_to_check.getGlobalBounds().top;
	float bottom = text_to_check.getGlobalBounds().top + text_to_check.getGlobalBounds().height;
	if (left< mouse.getPosition(window).x && right > mouse.getPosition(window).x)
	{
		if (top < mouse.getPosition(window).y && bottom > mouse.getPosition(window).y)
		{
			return true;
		}
		return false;
	}
	return false;
}
