#pragma once
#include<SFML/Graphics.hpp>
using namespace sf;
using namespace std;

#define MAX_NUMBER_OF_ITEMS 2

class Menu
{
public:
	Menu(float width, float height);
	~Menu() = default;

	void draw(RenderWindow& window);
	void update();

private:
	void MoveUp();
	void MoveDown();
	int selectedItemIndex;
	Font font;
	Text menu[MAX_NUMBER_OF_ITEMS];

};

