#include "Menu.h"

Menu::Menu(float width, float height)
{
	if (!font.loadFromFile("arial.ttf"))
	{
		//handle error
	}

	menu[0].setFont(font);
	menu[0].setFillColor(Color::Cyan);
	menu[0].setString("Play");
	menu[0].setPosition(Vector2f(width / 2, height / (MAX_NUMBER_OF_ITEMS + 1)));

	menu[1].setFont(font);
	menu[1].setFillColor(Color::Black);
	menu[1].setString("Exit");
	menu[1].setPosition(Vector2f(width / 2, height / (MAX_NUMBER_OF_ITEMS + 1)*2));

	selectedItemIndex = 0;

}

void Menu::draw(RenderWindow &window)
{
	for (int i = 0; i < MAX_NUMBER_OF_ITEMS; i++)
	{
		window.draw(menu[i]);
	}

}

void Menu::update()
{
	for (size_t i = 0; i < MAX_NUMBER_OF_ITEMS; i++)
	{
		menu[i].setFillColor(Color::Black);
	}
	menu[selectedItemIndex].setFillColor(Color::Cyan);

	if (Keyboard::isKeyPressed(Keyboard::Key::Down))
	{
		MoveDown();
		return;
	}
	else if (Keyboard::isKeyPressed(Keyboard::Key::Up))
	{
		MoveUp();
		return;
	}
	
}

void Menu::MoveUp()
{
	selectedItemIndex--;
	if (selectedItemIndex < 0)
		selectedItemIndex = 1;

}

void Menu::MoveDown()
{
	selectedItemIndex++;
	if (selectedItemIndex > 1)
		selectedItemIndex = 0;
}
